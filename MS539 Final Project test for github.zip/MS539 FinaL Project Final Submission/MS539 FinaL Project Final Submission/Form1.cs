﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* ****** Final Project Intro **********
 * MS539
 * Jeff O'Hara
 * 2/23/24
 * The Final Final Project..
 * 
 * This project is a Dog Chooser Quiz that will utilize functions, variables, loops, operators, conditionals, an array,
 * multiple GUI components, and multiple forms to demonstrate each module we learned over the semester. My project will
 * allow the user to choose between several variables/questions, and click a button to see the results of their choices
 * in the quiz.
 * 
 * 2/23/24
 * Started @ 1300 hours
 * Started searching for more images to complete the neccessary amount for the choices the user could make on the web 
 * which took approx 1 hour. Actually started setting up the basic GUI elements for the first and second page at around
 * 1400 hours. I plan to have the GUI elements for all pages completed for today and hopefully some coding as well,
 * but fully anticipate tomorrow to be a day full of coding for this project. Sunday should be set aside for cleaning up 
 * any bad GUI elements and making sure the program is COMPLETELY user friendly. 
 * 
 * Quit for the day after testing the GUI setup and reconfiguring a few things on that aspect of the project.
 * Time is 1730 hours. 
 * Total work today: 0430 hours worked
 * 
 */

namespace MS539_FinaL_Project_Final_Submission
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Create a button for the user to click to start the quiz from the entry screen
        private void button1_Click(object sender, EventArgs e)
        {
            Answer_The_Questions_To_Find_Your_Match f2 = new Answer_The_Questions_To_Find_Your_Match();
            f2.Show();
            this.Hide();
        }
    }
}
