﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_FinaL_Project_Final_Submission
{
    public partial class Answer_The_Questions_To_Find_Your_Match : Form
    {
        public Answer_The_Questions_To_Find_Your_Match()
        {
            InitializeComponent();
        }

        private void RBLargeBreedDogAnswer_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RBSmallBreedDogAnswer_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RBLongHairDogAnswer_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RBShorHairDogAnswer_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RBHypoYesAnswer_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RBHypoNoAnswer_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BTNQuizResults_Click(object sender, EventArgs e)
        {

        }

        private void Answer_The_Questions_To_Find_Your_Match_Load(object sender, EventArgs e)
        {

        }
    }
}
