﻿namespace MS539_FinaL_Project_Final_Submission
{
    partial class Answer_The_Questions_To_Find_Your_Match
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Answer_The_Questions_To_Find_Your_Match));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.GBQuesiton1 = new System.Windows.Forms.GroupBox();
            this.RBSmallBreedDogAnswer = new System.Windows.Forms.RadioButton();
            this.RBLargeBreedDogAnswer = new System.Windows.Forms.RadioButton();
            this.GBQuestion2 = new System.Windows.Forms.GroupBox();
            this.RBShorHairDogAnswer = new System.Windows.Forms.RadioButton();
            this.RBLongHairDogAnswer = new System.Windows.Forms.RadioButton();
            this.GBQuestion3 = new System.Windows.Forms.GroupBox();
            this.RBHypoNoAnswer = new System.Windows.Forms.RadioButton();
            this.RBHypoYesAnswer = new System.Windows.Forms.RadioButton();
            this.BTNQuizResults = new System.Windows.Forms.Button();
            this.GBQuesiton1.SuspendLayout();
            this.GBQuestion2.SuspendLayout();
            this.GBQuestion3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(156, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Question 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(156, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 46);
            this.label2.TabIndex = 1;
            this.label2.Text = "Question 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(156, 408);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 46);
            this.label3.TabIndex = 2;
            this.label3.Text = "Question 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(193, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(841, 37);
            this.label4.TabIndex = 3;
            this.label4.Text = "Do you want a Large breed dog or a Small breed dog?";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(193, 295);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(796, 37);
            this.label5.TabIndex = 4;
            this.label5.Text = "Woud you like a Long hair dog or a Short hair dog?";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(193, 489);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(554, 37);
            this.label6.TabIndex = 5;
            this.label6.Text = "Do you want a Hypoallergenic dog?";
            // 
            // GBQuesiton1
            // 
            this.GBQuesiton1.BackColor = System.Drawing.Color.Transparent;
            this.GBQuesiton1.Controls.Add(this.RBSmallBreedDogAnswer);
            this.GBQuesiton1.Controls.Add(this.RBLargeBreedDogAnswer);
            this.GBQuesiton1.Location = new System.Drawing.Point(1190, 34);
            this.GBQuesiton1.Name = "GBQuesiton1";
            this.GBQuesiton1.Size = new System.Drawing.Size(382, 139);
            this.GBQuesiton1.TabIndex = 6;
            this.GBQuesiton1.TabStop = false;
            // 
            // RBSmallBreedDogAnswer
            // 
            this.RBSmallBreedDogAnswer.AutoSize = true;
            this.RBSmallBreedDogAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBSmallBreedDogAnswer.Location = new System.Drawing.Point(26, 80);
            this.RBSmallBreedDogAnswer.Name = "RBSmallBreedDogAnswer";
            this.RBSmallBreedDogAnswer.Size = new System.Drawing.Size(199, 29);
            this.RBSmallBreedDogAnswer.TabIndex = 1;
            this.RBSmallBreedDogAnswer.TabStop = true;
            this.RBSmallBreedDogAnswer.Text = "Small Breed Dog";
            this.RBSmallBreedDogAnswer.UseVisualStyleBackColor = true;
            this.RBSmallBreedDogAnswer.CheckedChanged += new System.EventHandler(this.RBSmallBreedDogAnswer_CheckedChanged);
            // 
            // RBLargeBreedDogAnswer
            // 
            this.RBLargeBreedDogAnswer.AutoSize = true;
            this.RBLargeBreedDogAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBLargeBreedDogAnswer.Location = new System.Drawing.Point(26, 26);
            this.RBLargeBreedDogAnswer.Name = "RBLargeBreedDogAnswer";
            this.RBLargeBreedDogAnswer.Size = new System.Drawing.Size(200, 29);
            this.RBLargeBreedDogAnswer.TabIndex = 0;
            this.RBLargeBreedDogAnswer.TabStop = true;
            this.RBLargeBreedDogAnswer.Text = "Large Breed Dog";
            this.RBLargeBreedDogAnswer.UseVisualStyleBackColor = true;
            this.RBLargeBreedDogAnswer.CheckedChanged += new System.EventHandler(this.RBLargeBreedDogAnswer_CheckedChanged);
            // 
            // GBQuestion2
            // 
            this.GBQuestion2.BackColor = System.Drawing.Color.Transparent;
            this.GBQuestion2.Controls.Add(this.RBShorHairDogAnswer);
            this.GBQuestion2.Controls.Add(this.RBLongHairDogAnswer);
            this.GBQuestion2.Location = new System.Drawing.Point(1190, 243);
            this.GBQuestion2.Name = "GBQuestion2";
            this.GBQuestion2.Size = new System.Drawing.Size(382, 139);
            this.GBQuestion2.TabIndex = 7;
            this.GBQuestion2.TabStop = false;
            // 
            // RBShorHairDogAnswer
            // 
            this.RBShorHairDogAnswer.AutoSize = true;
            this.RBShorHairDogAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBShorHairDogAnswer.Location = new System.Drawing.Point(26, 88);
            this.RBShorHairDogAnswer.Name = "RBShorHairDogAnswer";
            this.RBShorHairDogAnswer.Size = new System.Drawing.Size(179, 29);
            this.RBShorHairDogAnswer.TabIndex = 1;
            this.RBShorHairDogAnswer.TabStop = true;
            this.RBShorHairDogAnswer.Text = "Short Hair Dog";
            this.RBShorHairDogAnswer.UseVisualStyleBackColor = true;
            this.RBShorHairDogAnswer.CheckedChanged += new System.EventHandler(this.RBShorHairDogAnswer_CheckedChanged);
            // 
            // RBLongHairDogAnswer
            // 
            this.RBLongHairDogAnswer.AutoSize = true;
            this.RBLongHairDogAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBLongHairDogAnswer.Location = new System.Drawing.Point(26, 35);
            this.RBLongHairDogAnswer.Name = "RBLongHairDogAnswer";
            this.RBLongHairDogAnswer.Size = new System.Drawing.Size(175, 29);
            this.RBLongHairDogAnswer.TabIndex = 0;
            this.RBLongHairDogAnswer.TabStop = true;
            this.RBLongHairDogAnswer.Text = "Long Hair Dog";
            this.RBLongHairDogAnswer.UseVisualStyleBackColor = true;
            this.RBLongHairDogAnswer.CheckedChanged += new System.EventHandler(this.RBLongHairDogAnswer_CheckedChanged);
            // 
            // GBQuestion3
            // 
            this.GBQuestion3.BackColor = System.Drawing.Color.Transparent;
            this.GBQuestion3.Controls.Add(this.RBHypoNoAnswer);
            this.GBQuestion3.Controls.Add(this.RBHypoYesAnswer);
            this.GBQuestion3.Location = new System.Drawing.Point(1190, 434);
            this.GBQuestion3.Name = "GBQuestion3";
            this.GBQuestion3.Size = new System.Drawing.Size(382, 139);
            this.GBQuestion3.TabIndex = 7;
            this.GBQuestion3.TabStop = false;
            // 
            // RBHypoNoAnswer
            // 
            this.RBHypoNoAnswer.AutoSize = true;
            this.RBHypoNoAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBHypoNoAnswer.Location = new System.Drawing.Point(206, 51);
            this.RBHypoNoAnswer.Name = "RBHypoNoAnswer";
            this.RBHypoNoAnswer.Size = new System.Drawing.Size(64, 29);
            this.RBHypoNoAnswer.TabIndex = 1;
            this.RBHypoNoAnswer.TabStop = true;
            this.RBHypoNoAnswer.Text = "No";
            this.RBHypoNoAnswer.UseVisualStyleBackColor = true;
            this.RBHypoNoAnswer.CheckedChanged += new System.EventHandler(this.RBHypoNoAnswer_CheckedChanged);
            // 
            // RBHypoYesAnswer
            // 
            this.RBHypoYesAnswer.AutoSize = true;
            this.RBHypoYesAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBHypoYesAnswer.Location = new System.Drawing.Point(81, 53);
            this.RBHypoYesAnswer.Name = "RBHypoYesAnswer";
            this.RBHypoYesAnswer.Size = new System.Drawing.Size(74, 29);
            this.RBHypoYesAnswer.TabIndex = 0;
            this.RBHypoYesAnswer.TabStop = true;
            this.RBHypoYesAnswer.Text = "Yes";
            this.RBHypoYesAnswer.UseVisualStyleBackColor = true;
            this.RBHypoYesAnswer.CheckedChanged += new System.EventHandler(this.RBHypoYesAnswer_CheckedChanged);
            // 
            // BTNQuizResults
            // 
            this.BTNQuizResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNQuizResults.Location = new System.Drawing.Point(1896, 295);
            this.BTNQuizResults.Name = "BTNQuizResults";
            this.BTNQuizResults.Size = new System.Drawing.Size(269, 119);
            this.BTNQuizResults.TabIndex = 8;
            this.BTNQuizResults.Text = "Click to see the results of your test.";
            this.BTNQuizResults.UseVisualStyleBackColor = true;
            this.BTNQuizResults.Click += new System.EventHandler(this.BTNQuizResults_Click);
            // 
            // Answer_The_Questions_To_Find_Your_Match
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MS539_FinaL_Project_Final_Submission.Properties.Resources.FieldBackgroundMedium;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(2482, 1566);
            this.Controls.Add(this.BTNQuizResults);
            this.Controls.Add(this.GBQuestion3);
            this.Controls.Add(this.GBQuestion2);
            this.Controls.Add(this.GBQuesiton1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Answer_The_Questions_To_Find_Your_Match";
            this.Text = "Answer The Questions To Find Your Match";
            this.Load += new System.EventHandler(this.Answer_The_Questions_To_Find_Your_Match_Load);
            this.GBQuesiton1.ResumeLayout(false);
            this.GBQuesiton1.PerformLayout();
            this.GBQuestion2.ResumeLayout(false);
            this.GBQuestion2.PerformLayout();
            this.GBQuestion3.ResumeLayout(false);
            this.GBQuestion3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox GBQuesiton1;
        private System.Windows.Forms.GroupBox GBQuestion2;
        private System.Windows.Forms.GroupBox GBQuestion3;
        private System.Windows.Forms.RadioButton RBSmallBreedDogAnswer;
        private System.Windows.Forms.RadioButton RBLargeBreedDogAnswer;
        private System.Windows.Forms.RadioButton RBShorHairDogAnswer;
        private System.Windows.Forms.RadioButton RBLongHairDogAnswer;
        private System.Windows.Forms.RadioButton RBHypoNoAnswer;
        private System.Windows.Forms.RadioButton RBHypoYesAnswer;
        private System.Windows.Forms.Button BTNQuizResults;
    }
}